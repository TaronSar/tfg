import networkx as nx
import pandas as pd
import numpy as np
import math
import scipy.io
import time
import random
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import os
from importlib.resources import files
import csv


pd.options.mode.chained_assignment = None
global_model_name = None

#Identify frequency table column to sample
def get_ind(siz, x):
    k = np.cumprod([1] + siz[:-1])
    #print(k)
    ndx = np.dot(k, (np.array(x) - 1)) + 1
    return ndx

#Sample from frequency table selected column
def get_random(weights, rng):
    #print(weights)
    r = rng.random()
    s = np.cumsum(weights)
    sthres = s[-1] * r
    x = s >= sthres
    index = np.argmax(x)
    #print(f"Randon Val: {r}, Idx selected: {index}")
    return index

#Add columns for transition distribution
def prepare_evidence_dataframe(X):
    # Add columns for Acceleration1, Vertical Rate1 y Turn Rate1 con valores 0
    X['Acceleration1'] = 0
    X['VRate1'] = 0
    X['TRate1'] = 0
    return X

# Convert discrete sampled values back to continuous form
def revert_discretization(binEdges, data_val, rng):
    binStart = binEdges[data_val]
    binEnd = binEdges[data_val + 1]
    if binStart <= 0 and binEnd >= 0:
        return 0
    else:
        return binStart + (binEnd - binStart) * rng.random()


def generate_straight_flight_profile(initial_values, control):
    initial_profile = np.array(initial_values, dtype=float, copy=True)
    control_profile = np.array(control, dtype=float, copy=True)

    # Keep vertical-rate and acceleration commands, force no heading change.
    initial_profile[-1] = 0.0
    if control_profile.ndim == 2 and control_profile.shape[1] > 3:
        control_profile[:, 3] = 0.0

    return initial_profile, control_profile


def _normalize_lla_points(lla_points):
    points = np.asarray(lla_points, dtype=float)
    if points.ndim != 2 or points.shape[1] != 3:
        raise ValueError("lla_points must be a Nx3 array-like of [latitude_deg, longitude_deg, altitude].")
    if points.shape[0] < 2:
        raise ValueError("At least two LLA points are required to generate a trajectory.")
    return points


def _clone_track_result(track_result):
    return {
        key: value.copy() if isinstance(value, np.ndarray) else value
        for key, value in track_result.items()
    }


def _load_lla_points_from_csv(csv_filename):
    if not os.path.isfile(csv_filename):
        raise FileNotFoundError(f"The trajectory CSV file was not found: {csv_filename}")

    df = pd.read_csv(csv_filename)
    if df.empty:
        raise ValueError("The trajectory CSV file is empty.")

    normalized_columns = {col.strip().lower(): col for col in df.columns}

    lat_candidates = ['latitude', 'lat', 'latitude_deg']
    lon_candidates = ['longitude', 'lon', 'lng', 'longitude_deg']
    alt_candidates = ['altitude', 'alt', 'height', 'altitude_m']

    def _find_column(candidates):
        for name in candidates:
            if name in normalized_columns:
                return normalized_columns[name]
        return None

    lat_col = _find_column(lat_candidates)
    lon_col = _find_column(lon_candidates)
    alt_col = _find_column(alt_candidates)

    if lat_col is None or lon_col is None or alt_col is None:
        # Fallback to first three columns if header names are not standard.
        if df.shape[1] < 3:
            raise ValueError(
                "CSV must contain latitude, longitude, altitude columns (or at least 3 columns)."
            )
        lat_col, lon_col, alt_col = df.columns[:3]

    lla_points = df[[lat_col, lon_col, alt_col]].to_numpy(dtype=float)
    return _normalize_lla_points(lla_points)


def _lla_to_ecef(lat_rad, lon_rad, alt_m):
    semi_major_axis = 6378137.0
    eccentricity_sq = 6.69437999014e-3

    sin_lat = np.sin(lat_rad)
    cos_lat = np.cos(lat_rad)
    sin_lon = np.sin(lon_rad)
    cos_lon = np.cos(lon_rad)

    prime_vertical = semi_major_axis / np.sqrt(1.0 - eccentricity_sq * sin_lat * sin_lat)

    x = (prime_vertical + alt_m) * cos_lat * cos_lon
    y = (prime_vertical + alt_m) * cos_lat * sin_lon
    z = (prime_vertical * (1.0 - eccentricity_sq) + alt_m) * sin_lat
    return np.column_stack((x, y, z))


def _ecef_to_enu(ecef_xyz, ref_lat_rad, ref_lon_rad, ref_ecef_xyz):
    delta = ecef_xyz - ref_ecef_xyz

    sin_lat = math.sin(ref_lat_rad)
    cos_lat = math.cos(ref_lat_rad)
    sin_lon = math.sin(ref_lon_rad)
    cos_lon = math.cos(ref_lon_rad)

    east_m = -sin_lon * delta[:, 0] + cos_lon * delta[:, 1]
    north_m = -sin_lat * cos_lon * delta[:, 0] - sin_lat * sin_lon * delta[:, 1] + cos_lat * delta[:, 2]
    up_m = cos_lat * cos_lon * delta[:, 0] + cos_lat * sin_lon * delta[:, 1] + sin_lat * delta[:, 2]

    return east_m, north_m, up_m


def gen_track_from_lla(lla_points, desired_speed_kt, altitude_unit='m'):
    if desired_speed_kt is None or float(desired_speed_kt) <= 0:
        raise ValueError("desired_speed_kt must be a positive value.")

    g_ftps2 = 32.2
    max_bank_rad = 75.0 * math.pi / 180.0
    low_speed_blend_start_kt = 30.0
    high_speed_blend_end_kt = 50.0

    normalized_points = _normalize_lla_points(lla_points)
    lat_deg = normalized_points[:, 0]
    lon_deg = normalized_points[:, 1]
    alt_values = normalized_points[:, 2]

    altitude_unit_normalized = altitude_unit.lower()
    if altitude_unit_normalized == 'm':
        altitude_m = alt_values
    elif altitude_unit_normalized == 'ft':
        altitude_m = alt_values * 0.3048
    else:
        raise ValueError("altitude_unit must be either 'm' or 'ft'.")

    lat_rad = np.radians(lat_deg)
    lon_rad = np.radians(lon_deg)
    ecef_xyz = _lla_to_ecef(lat_rad, lon_rad, altitude_m)
    east_m, north_m, up_m = _ecef_to_enu(ecef_xyz, lat_rad[0], lon_rad[0], ecef_xyz[0])

    north_ft = north_m / 0.3048
    east_ft = east_m / 0.3048
    up_ft = up_m / 0.3048

    position_ft = np.column_stack((north_ft, east_ft, up_ft))
    delta_ft = np.diff(position_ft, axis=0)
    segment_lengths_ft = np.linalg.norm(delta_ft, axis=1)
    speed_ftps = float(desired_speed_kt) * 1.68780972222222
    segment_dt = np.divide(
        segment_lengths_ft,
        speed_ftps,
        out=np.zeros_like(segment_lengths_ft, dtype=float),
        where=speed_ftps > 1e-9,
    )
    time_s = np.concatenate(([0.0], np.cumsum(segment_dt)))

    psi_rad = np.zeros(len(normalized_points), dtype=float)
    theta_rad = np.zeros(len(normalized_points), dtype=float)
    phi_rad = np.zeros(len(normalized_points), dtype=float)
    turn_rate_radps = np.zeros(len(normalized_points), dtype=float)
    lateral_acc_ftps2 = np.zeros(len(normalized_points), dtype=float)

    if len(delta_ft) > 0:
        horizontal_ft = np.hypot(delta_ft[:, 0], delta_ft[:, 1])
        segment_psi = np.arctan2(delta_ft[:, 1], delta_ft[:, 0])
        segment_theta = np.arctan2(delta_ft[:, 2], np.maximum(horizontal_ft, 1e-9))
        psi_rad[:-1] = segment_psi
        psi_rad[-1] = segment_psi[-1]
        theta_rad[:-1] = segment_theta
        theta_rad[-1] = segment_theta[-1]

        if len(time_s) > 1:
            unwrapped_psi = np.unwrap(psi_rad)
            turn_rate_radps = np.gradient(unwrapped_psi, time_s)
            lateral_acc_ftps2 = speed_ftps * turn_rate_radps

            # At low speed, output a lateral-acceleration-equivalent roll signal.
            low_speed_roll_rad = lateral_acc_ftps2 / g_ftps2

            # At higher speed, output the coordinated-turn bank angle.
            coordinated_bank_rad = np.arctan2(lateral_acc_ftps2, g_ftps2)

            blend = np.clip(
                (float(desired_speed_kt) - low_speed_blend_start_kt)
                / (high_speed_blend_end_kt - low_speed_blend_start_kt),
                0.0,
                1.0,
            )
            phi_rad = (1.0 - blend) * low_speed_roll_rad + blend * coordinated_bank_rad
            phi_rad = np.clip(phi_rad, -max_bank_rad, max_bank_rad)

    return {
        'time': time_s,
        'north_ft': north_ft,
        'east_ft': east_ft,
        'up_ft': up_ft,
        'speed_ftps': np.full(len(normalized_points), speed_ftps, dtype=float),
        'phi_rad': phi_rad,
        'theta_rad': theta_rad,
        'psi_rad': psi_rad,
        'actual_speed': float(desired_speed_kt),
    }
    


def simulation_new(IN_INIT_1, IN_C_1, IN_DYN_1, IN_R):
    dt = 0.1  # Time step [s]
    K = 1     # Integration gain
    g = 32.2  # Acceleration of gravity [ft/s^2]
    MAX_PHI = 75 * np.pi / 180
    MAX_PHI_DOT = 0.524
    NUM_AC = 1 

    initial_AC1 = IN_INIT_1
    controls_AC1 = IN_C_1
    dynamics_AC1 = IN_DYN_1
    runtime_s = IN_R

    breakflag = 0  
    renc_ft = 1000000  
    henc_ft = 1000000  
    minsimtime = 0

    NUM_INIT = 8  
    NUM_DYN = 6   

    v_ftps_min = dynamics_AC1[0]
    v_ftps_max = dynamics_AC1[1]
    dh_ftps_min = dynamics_AC1[2]
    dh_ftps_max = dynamics_AC1[3]
    qmax = dynamics_AC1[4]
    rmax = dynamics_AC1[5]
    
    # Initialize states for the aircraft
    x = np.array(initial_AC1) 
    
    # Determine number of time steps
    nvalues = int(runtime_s / dt + 1)

    bufout = np.full((nvalues, NUM_AC * 8), np.nan) 

    currt = 0

    bufout[0, 0:8] = [currt, x[1], x[2], x[3], x[0], x[6], x[5], x[4]]

    val = 1
    
    # Loop through each time step
    for i in range(1, nvalues):
        currt = i * dt  

        # Determine current command index
        cmd_i = np.where(controls_AC1[:, 0] == currt)[0]
        if cmd_i.size == 0:
            cmd_i = val
        else:
            val = cmd_i[0]
        
        if isinstance(cmd_i, np.ndarray):
            cmd_i=cmd_i.item()
        
        # Run dynamics for Aircraft
        x = integrateAircraftDynamics(x, controls_AC1, dynamics_AC1, cmd_i)

        bufout[i, 0:8] = [currt, x[1], x[2], x[3], x[0], x[6], x[5], x[4]]

    # Format outputs
    for ac in range(NUM_AC):
        results_ac = {
            'time': bufout[:, 0],
            'north_ft': bufout[:, 1 + (ac - 1) * 8],
            'east_ft': bufout[:, 1 + 1 + (ac - 1) * 8],
            'up_ft': bufout[:, 2 + 1 + (ac - 1) * 8],
            'speed_ftps': bufout[:, 3 + 1 + (ac - 1) * 8],
            'phi_rad': bufout[:, 4 + 1 + (ac - 1) * 8],
            'theta_rad': bufout[:, 5 + 1 + (ac - 1) * 8],
            'psi_rad': bufout[:, 6 + 1 + (ac - 1) * 8],
        }

        # Average true airspeed in knots for convenience when comparing against desired_speed_kt.
        results_ac['actual_speed'] = float(np.mean(results_ac['speed_ftps']) / 1.68780972222222)

    return results_ac
   # return bufout

def integrateAircraftDynamics(x, controls, dynamics, cmd_i):
  
    dt = 0.1  # Time step [s]
    K = 1     # Integration gain
    g = 32.2  # Gravity [ft/s^2]
    MAX_PHI = 75 * np.pi / 180 # Maximum bank angle [rad]
    MAX_PHI_DOT = 0.524 # Maximum roll rate [rad/s]
    
    # Extract dynamics parameters
    v_ftps_min = dynamics[0]  #Min velocity [ft/s]
    v_ftps_max = dynamics[1]  #Max velocity [ft/s]
    dh_ftps_min = dynamics[2] #Min vertical rate [ft/s]
    dh_ftps_max = dynamics[3] #Max vertical rate [ft/s]
    qmax = dynamics[4]        #Max pitch rate [rad/s]
    rmax = dynamics[5]        #Max yaw rate [rad/s]

    # Extract control commands
    acmd = controls[cmd_i, 1]    # Commanded acceleration [ft/s^2]
    dpsicmd = controls[cmd_i, 3] # Commanded change in heading [rad/s]
    dhcmd = controls[cmd_i, 2]   #Commanded vertical rate [ft/s]
    
    # Saturate vertical rate command within allowable limits
    dhcmd = max(min(dh_ftps_max, dhcmd), dh_ftps_min)  

    # Trigonometric values
    s_theta = np.sin(x[5]) #Pitch
    c_theta = np.cos(x[5])
    t_theta = np.tan(x[5])
    s_phi = np.sin(x[6])   #Bank
    c_phi = np.cos(x[6])
    s_psi = np.sin(x[4])   #Yaw
    c_psi = np.cos(x[4])

    # Current vertical speed and desired vertical acceleration
    hd = x[0] * s_theta
    hddcmd = 1 / dt * (dhcmd - hd)

    #Compute and saturate the pitch rate (q)
    q = 1 / (max(x[0], 1) * c_phi) * (hddcmd / c_theta + g * c_theta * s_phi * s_phi - acmd * t_theta)
    q = min(max(q, -qmax), qmax)

    # Compute and saturate the yaw rate (r)
    r = g * s_phi * c_theta / max(x[0], 1)
    r = min(max(r, -rmax), rmax)

    # Maximum allowable bank angle (phimax)
    hdd_cmd_phi = min(hddcmd, max(x[0], 1) * qmax * c_phi * c_theta)

    sqrt_arg = (max(x[0], 1))**2 * (qmax)**2 - 4 * g * acmd * s_theta + 4 * g * hdd_cmd_phi + 4 * (g)**2 * (c_theta)**2
    if sqrt_arg < 0:
        phi_max_2 = 10000
    else:
        cphi1 = (-max(x[0], 1) * qmax + np.sqrt(sqrt_arg)) / (2 * g * c_theta)

        if abs(cphi1) < 1:
            phi_max_2 = np.arccos(cphi1) * 0.98 
        else:
            phi_max_2 = 0  

    phimax = min(MAX_PHI, phi_max_2)

    # Compute and saturate the roll rate (p)  
    phi_cmd0 = np.arctan(dpsicmd * x[0] / g)
    psidot_if_no_change = (q * s_phi + r * c_phi) / c_theta
    dpsidot = dpsicmd - psidot_if_no_change
    #p = 20 * dpsidot
    p=0 * (phi_cmd0 - x[6]) + 20 * dpsidot + 0.0 * 0

    # Limit max rollrate
    if p > MAX_PHI_DOT:
        p = MAX_PHI_DOT
    elif p < -MAX_PHI_DOT:
        p = -MAX_PHI_DOT

    # Limit max bank angle
    if x[6] + p * dt > phimax:
        p = (phimax - x[6]) / dt
    elif x[6] + p * dt < -phimax:
        p = (-phimax - x[6]) / dt

    # Compute angular rates for roll, pitch, and yaw
    phidot = p + q * s_phi * t_theta + r * c_phi * t_theta
    thetadot = q * c_phi - r * s_phi
    psidot = q * s_phi / c_theta + r * c_phi / c_theta

    # Compute position rates (North, East, and vertical)
    Ndot = x[0] * c_theta * c_psi
    Edot = x[0] * c_theta * s_psi
    hdot = x[0] * s_theta
    

    # Backwards Euler integration of the states 
    x[0] = x[0] + acmd * dt * K
    x[1] = x[1] + Ndot * dt * K
    x[2] = x[2] + Edot * dt * K
    x[3] = x[3] + hdot * dt * K
    x[6] = x[6] + phidot * dt * K
    x[5] = x[5] + thetadot * dt * K
    x[4] = x[4] + psidot * dt * K

    # Saturate velocity within allowable limits
    if x[0] < v_ftps_min:
        x[0] = v_ftps_min
    if x[0] >= v_ftps_max:
        x[0] = v_ftps_max - 0.000001

    return x

def get_limits(N_initial, boundaries,isRotorcraft,Labels):
    #Calculate dynamic limits based on cutpoints
    idx_L=Labels.index('Altitude')
    idx_V = Labels.index('Speed')
    idx_DH = Labels.index('VRate')
    
    min_alt_ft = np.min(boundaries[idx_L])
    max_alt_ft = np.max(boundaries[idx_L])
    #print(f"idx_V={idx_V}, idx_DH={idx_DH}")
    v_initial = np.sum(N_initial[idx_V,0], axis=1)
    dh_initial = np.sum(N_initial[idx_DH,0], axis=1)
    #print(f"v_initial={v_initial}, dh_initial={dh_initial}")
    
    prct_low = 1
    prct_high = 99

    prob_V = 100*(v_initial/np.sum(v_initial, axis=0))
    #print(f"sum(v_initial,axis=0)=,prob_V ={prob_V}")
    cs_V = np.cumsum(prob_V)
    #print(f"cs_V={cs_V}")
    k_min_V = np.argmax(cs_V >= prct_low)
    k_max_V = np.argmax(cs_V >= prct_high)
    #print(f"k_min_V={k_min_V}, k_max_V={k_max_V}")

    min_speed_ft_s = boundaries[idx_V][0,k_min_V + 1] * 1.68780972222222  # v: KTAS -> ft/s
    max_speed_ft_s = boundaries[idx_V][0,k_max_V + 1] * 1.68780972222222  # v: KTAS -> ft/s
    #print(f"min_speed_ft_s={min_speed_ft_s}, max_speed_ft_s={max_speed_ft_s}")

    if isRotorcraft and max_speed_ft_s > 304:
        max_speed_ft_s = 304
    if not isRotorcraft and min_speed_ft_s < 30:
        min_speed_ft_s = 30

    prob_DH = 100 * (dh_initial / np.sum(dh_initial,axis=0))
    cs_DH = np.cumsum(prob_DH)
    k_min_DH = np.argmax(cs_DH >= prct_low)
    k_max_DH = np.argmax(cs_DH >= prct_high)
    #print(f"k_min_DH={k_min_DH}, k_max_DH={k_max_DH}")

    max_vertrate_ft_s = max(abs(boundaries[idx_DH][0,k_min_DH+1])/60,abs(boundaries[idx_DH][0,k_max_DH+1])/ 60)
    #print(f"max_vertrate_ft_s={max_vertrate_ft_s}")
    if np.isnan(max_vertrate_ft_s):
        max_vertrate_ft_s = 0

    dynamiclimits = {
        'minVel_ft_s': min_speed_ft_s,
        'maxVel_ft_s': max_speed_ft_s,
        'maxVertRate_ft_s': max_vertrate_ft_s
    }
    return min_alt_ft, max_alt_ft, dynamiclimits


def get_track_data(Initial_org, data, Cut_Points, Order_Cutpoints, resample, sample_time,idx_Ac,idx_TR, desired_speed_kt=None, rng=None, straight_flight=False, lla_points=None):
    if rng is None:
        rng = np.random.default_rng()

    if lla_points is not None:
        if desired_speed_kt is None:
            raise ValueError("desired_speed_kt is required when generating track data from LLA points.")
        return gen_track_from_lla(lla_points, desired_speed_kt)
    
    #Select appropiate labels
    if len(Initial_org.keys())==6:
        rearrange_In = ['Airspace', 'Altitude', 'Speed', 'Acceleration', 'VRate', 'TRate']
        inc=2
    else:
        rearrange_In = ['WTC','Airspace', 'Altitude', 'Speed', 'Acceleration', 'VRate', 'TRate']
        inc=3
            
        
    Initial_rev = np.zeros(len(Initial_org.keys()))
    
    # Revert Discretization Initial
    for i in range(len(Initial_org.keys())):
        edges = Cut_Points[Order_Cutpoints[i], 1].flatten()
        edges=edges.astype(float)
        if i == idx_Ac or i == idx_TR:
            if any(edge > 100 for edge in edges):
                edges = edges / 100
                Cut_Points[Order_Cutpoints[i], 1] = edges
        if np.all(np.diff(edges) == 1):
            Initial_rev[i] = np.array(Initial_org[rearrange_In[i]]).item()
        else:
            Initial_rev[i] = revert_discretization(edges, np.array(Initial_org[rearrange_In[i]]).item()-1, rng)
        #print(f"edges={edges}")
            
    #print(f"Print Initial{Initial_rev}")       

    #Revert Discretization Transition
    data = np.array(data)
    data_org = data
    data_org = np.column_stack((np.arange(sample_time), data_org))
    X_old = data_org[0, 1:4]
    data_resample = data_org.copy()
    data_resample=np.array(data_resample, dtype=float)
    data_resample[0, 1:4] = Initial_rev[-3:]
    to_delete = []
    #print(f"data resample:{data_resample}")

    #Perform resampling
    for i in range(1, len(data_resample)):
        sample_again = np.where(rng.random(resample.shape) < resample)[0] + 1
        if sample_again.size > 0:
            if not np.array_equal(X_old, data_resample[i, 1:4]):
                sample_again = np.unique(np.concatenate((sample_again, np.where(X_old != data_resample[i, 1:4])[0] + 1)))
            X_old = data_resample[i, 1:4].copy()
            data_resample[i, 1:4] = data_resample[i-1, 1:4].copy()
            for j in sample_again:
                edges = Cut_Points[Order_Cutpoints[j+inc], 1].flatten()
                data_resample[i, j] = revert_discretization(edges, int(X_old[j-1])-1, rng)
        else:
            if not np.array_equal(X_old, data_resample[i, 1:4]):
                sample_again = np.where(X_old != data_resample[i, 1:4])[0] + 1
                X_old = data_resample[i, 1:4].copy()
                data_resample[i, 1:4] = data_resample[i-1, 1:4].copy()
                for j in sample_again:
                    edges = Cut_Points[Order_Cutpoints[j+inc], 1].flatten()
                    data_resample[i, j] = revert_discretization(edges, int(X_old[j-1])-1, rng)
            else:
                data_resample[i, 1:4] = data_resample[i-1, 1:4].copy()
                to_delete.append(i)

    #print(f"data resample:{data_resample}") 
    control = np.delete(data_resample, to_delete, axis=0)
    #print('control: {control}')
    
    control[:, 2] = control[:, 2] / 60  # Convert fpm a fps
    control[:, 3] = control[:, 3] * (math.pi / 180)  # Convert deg/s to rad/s
    control[:, 1] = control[:, 1] * 1.68780972222222  # Convert kts/s to ft/s²

    if straight_flight:
        Initial_rev, control = generate_straight_flight_profile(Initial_rev, control)

    #print(f'control: {control}')

    #Unit conversions
    h_ft = Initial_rev[rearrange_In.index('Altitude')] 
    if desired_speed_kt is not None:
        Initial_rev[rearrange_In.index('Speed')] = float(desired_speed_kt)

    v_ft_s = Initial_rev[rearrange_In.index('Speed')] * 1.68780972222222   #KTAS -> ft/s 
    dv_ft_ss = Initial_rev[rearrange_In.index('Acceleration')] * 1.68780972222222   #kt/s -> ft/s^2
    dh_ft_s = Initial_rev[rearrange_In.index('VRate')] / 60  #ft/min -> ft/s
    dh_ft_s = max(min(dh_ft_s, v_ft_s/2.0), -v_ft_s/2.0)  # Limit vertical rate to half of total speed
    dpsi_rad_s = (math.pi / 180)*(Initial_rev[rearrange_In.index('TRate')])  #deg/s -> rad/s

    #Calculate heading, pitch and bank angles
    heading_rad = 0
    if abs(v_ft_s) < 1e-9:
        pitch_rad =0
    else:
        pitch_rad = math.asin(dh_ft_s / v_ft_s)

    bank_rad = math.atan(v_ft_s * dpsi_rad_s / 32.2)
    
    #Initial conditions for track 
    n_ft=0
    e_ft=0
    ic = [v_ft_s, n_ft, e_ft, h_ft, heading_rad, pitch_rad, bank_rad, dv_ft_ss]
    dyn = [1.7, max(Cut_Points[np.where(Cut_Points[:,0] == 'Speed')[0][0] , 1].flatten())* 1.68780972222222, min(Cut_Points[np.where(Cut_Points[:,0] == 'Vertical Rate')[0][0] , 1].flatten())/60, max(Cut_Points[np.where(Cut_Points[:,0] == 'Vertical Rate')[0][0] , 1].flatten())/60, (math.pi / 180)*3, 1000000]

    #print(f"ic={ic}")
    #print(f"control={control}")
    #print(f"dyn={dyn}")
    
    #Obtain track
    RESULTS = simulation_new(ic, control, dyn, sample_time)
    return RESULTS


def generate_valid_results(data_model,number_of_tracks, duration,seed, desired_speed_kt=None, straight_flight=False, lla_points=None):

    if lla_points is not None:
        if desired_speed_kt is None:
            raise ValueError("desired_speed_kt is required when generating tracks from LLA points.")

        base_track = get_track_data(
            Initial_org=None,
            data=None,
            Cut_Points=None,
            Order_Cutpoints=None,
            resample=None,
            sample_time=duration,
            idx_Ac=None,
            idx_TR=None,
            desired_speed_kt=desired_speed_kt,
            rng=np.random.default_rng(1 if seed is True else None),
            straight_flight=False,
            lla_points=lla_points,
        )

        valid_results = [_clone_track_result(base_track) for _ in range(int(number_of_tracks))]
        empty_initial = pd.DataFrame()
        all_results_by_X = []
        return valid_results, empty_initial, all_results_by_X
    
    #Extract data from MAtlab file
    G_matrix_initial= data_model['DAG_Initial']
    G_initial = nx.from_numpy_array(G_matrix_initial, create_using=nx.DiGraph)
    order_initial = list(nx.topological_sort(G_initial))

    G_matrix_transition= data_model['DAG_Transition']
    G_transition = nx.from_numpy_array(G_matrix_transition, create_using=nx.DiGraph)
    order_transition = list(nx.topological_sort(G_transition))
    
    N_initial=data_model['N_initial']
    N_transition = data_model['N_transition']
    
    dynamic_variables=order_transition[-3:]
    dynamic_variables.sort()

    #Select appropiate labels
    if len(order_initial) == 6:
        Labels = ['Airspace', 'Altitude', 'Speed', 'Acceleration', 'VRate', 'TRate']
    else:
        Labels = ['WTC', 'Airspace', 'Altitude', 'Speed', 'Acceleration', 'VRate', 'TRate']
    
   #Get Cut points and resample rate files
    Cut_Points = data_model['Cut_Points']
    resample_rate = data_model['resample_rate']
    resample = resample_rate[-3:, 0]
    
    #Added for old files
    airspace_exists = False
    for item in Cut_Points:
        if item[0][0] == 'Airspace':
            airspace_exists = True
            #print("'Airspace' está presente.")
            break

    # If Airspace is not present, add it
    if not airspace_exists:
        airspace_entry = [np.array(['Airspace'], dtype='<U8'), np.array([[1., 2., 3., 4., 5., 6., 7.]])]

        Cut_Points = Cut_Points.tolist()
        Cut_Points.append(airspace_entry)
        my_array = np.empty((len(Cut_Points), 2), dtype=object)

        for i, item in enumerate(Cut_Points):
            my_array[i, 0] = item[0]
            my_array[i, 1] = item[1]
        Cut_Points=my_array
    
    #Select appropiate labels for cutpoints
    if  len(order_initial)==6:
        if Cut_Points[0,0][0] == 'Aceleration':
            order_Cutpoints_labels = ['Airspace', 'Altitude', 'Speed', 'Aceleration', 'Vertical Rate', 'Turn Rate']
            idx_Ac = order_Cutpoints_labels.index('Aceleration')
        else:
            order_Cutpoints_labels = ['Airspace', 'Altitude', 'Speed', 'Acceleration', 'Vertical Rate', 'Turn Rate']
            idx_Ac = order_Cutpoints_labels.index('Acceleration')
    else:
        order_Cutpoints_labels = ['WTC','Airspace', 'Altitude', 'Speed', 'Acceleration', 'Vertical Rate', 'Turn Rate']
        idx_Ac = order_Cutpoints_labels.index('Acceleration')
    
    # Get index for cutpoints to adjust
    Order_Cutpoints = [np.where(Cut_Points[:,0] == label)[0][0] for label in order_Cutpoints_labels]
    idx_TR = order_Cutpoints_labels.index('Turn Rate')
    idx_Speed = Labels.index('Speed')
    speed_cut_idx = order_Cutpoints_labels.index('Speed')
    speed_edges = np.asarray(Cut_Points[Order_Cutpoints[speed_cut_idx], 1]).flatten().astype(float)
    boundaries = Cut_Points[Order_Cutpoints, 1]
    model_name = global_model_name.lower() if global_model_name else ""
    isRotorcraft = ('helicopter' in model_name) or ('gyrocopter' in model_name) or ('rotor' in model_name)
   
    
    #Obtain dynamic limits
    min_alt_ft, max_alt_ft,dynamiclimits= get_limits(N_initial, boundaries,isRotorcraft,Labels)
    if desired_speed_kt is not None:
        desired_speed_ftps = float(desired_speed_kt) * 1.68780972222222
        dynamiclimits['minVel_ft_s'] = min(dynamiclimits['minVel_ft_s'], desired_speed_ftps)
        dynamiclimits['maxVel_ft_s'] = max(dynamiclimits['maxVel_ft_s'], desired_speed_ftps)
    #print(f"min alt={min_alt_ft}, max alt={max_alt_ft}, min speed: {dynamiclimits['minVel_ft_s']}, min speed: {dynamiclimits['maxVel_ft_s']},max Vrate {dynamiclimits['maxVertRate_ft_s']}")
    
    dynvar_depend = np.any(G_matrix_transition[np.ix_(dynamic_variables, dynamic_variables)])
    
    valid_results = []
    invalid_results = []
    X_Initial_total=[]
    inX_Initial_total=[]
    all_results_by_X=[]
    inall_results_by_X=[]
    total_results = 0
    wrong_tracks=0
    
    if seed is True:
        base_seed = 1
    elif isinstance(seed, (int, np.integer, float)) and not isinstance(seed, bool):
        base_seed = int(seed)
    else:
        base_seed = None

    rng = np.random.default_rng(base_seed)

    adaptive_speed_kt = float(desired_speed_kt) if desired_speed_kt is not None else None

    attempts = 0
    max_attempts = max(1000, int(number_of_tracks) * 2000)

    while total_results < number_of_tracks:
        attempts += 1
        if attempts > max_attempts:
            raise RuntimeError(
                f"Unable to generate {number_of_tracks} valid tracks after {max_attempts} attempts. "
                f"Try relaxing constraints or increasing speed/vertical-rate limits."
            )
        S = np.zeros(len(order_initial), dtype=int)
        r = [arr[0].shape[0] for arr in N_initial]
        r = np.array(r)

        #Perform sampling initial 
        for i in order_initial:
            parents = G_matrix_initial[:, i]
            j = 0
            if np.any(parents):
                j = get_ind(r[parents == 1].tolist(), S[parents == 1].tolist())
            S[i] = get_random(N_initial[i][0][:, j-1], rng) + 1

        if adaptive_speed_kt is not None:
            speed_req_kt = float(adaptive_speed_kt)
            speed_req_kt = np.clip(speed_req_kt, speed_edges[0], speed_edges[-1])
            speed_bin_zero_based = np.searchsorted(speed_edges, speed_req_kt, side='right') - 1
            speed_bin_zero_based = int(np.clip(speed_bin_zero_based, 0, len(speed_edges) - 2))
            S[idx_Speed] = speed_bin_zero_based + 1

        X_initial = pd.DataFrame([S], columns=Labels)
        
        #Perform sampling transition
        r_t = [arr[0].shape[0] for arr in N_transition]
        r_t[:-3] = r
        r_t = np.array(r_t)
        X_initial_copy = X_initial.copy()
        X = prepare_evidence_dataframe(X_initial_copy)
        all_results = []
        X = X.to_numpy().reshape(-1)

        if dynvar_depend:
            for _ in range(duration):
                for i in order_transition[-3:]:
                    parents = G_matrix_transition[:, i]
                    j = 0
                    if np.any(parents):
                        j = get_ind(r_t[parents == 1].tolist(), X[parents == 1].tolist())
                    X[i] = get_random(N_transition[i][0][:, j-1], rng) + 1
                    X[i-3] = X[i]
                all_results.append(X[-3:].copy())
                X[-3:] = 0
        else:
            j = np.full(len(order_transition), np.nan)
            s = [None] * len(order_transition)
            sthres = np.zeros(((duration, len(order_transition))))

            for i in order_transition[-3:]:
                parents = G_matrix_transition[:, i]
                if np.any(parents):
                    j[i] = get_ind(r_t[parents == 1].tolist(),  X[parents == 1].tolist())
                else:
                    j[i] = 1

                s[i] = np.cumsum(N_transition[i][0][:, int(j[i])-1])
                sthres[:, i] = s[i][-1] * rng.random(duration)

            for t in range(0, duration):
                for i in order_transition[-3:]:
                    X[i] = np.searchsorted(s[i], sthres[t, i]) + 1
                    X[i-3] = X[i]
                all_results.append(X[-3:].copy())
                X[-3:] = 0


        #Obtain track based on sampling
        result = get_track_data(
            X_initial,
            all_results,
            Cut_Points,
            Order_Cutpoints,
            resample,
            duration,
            idx_Ac,
            idx_TR,
            desired_speed_kt=adaptive_speed_kt,
            rng=rng,
            straight_flight=straight_flight,
        )

        #Set dynamic limits
        dh = np.gradient(result['up_ft'], result['time'])
        results_dh_ft_s = abs(dh)
        is_violate_L = np.any((result['up_ft'] < min_alt_ft) | (result['up_ft'] > max_alt_ft+500))
        is_violate_V = np.any((result['speed_ftps'] < dynamiclimits['minVel_ft_s']) | (result['speed_ftps'] > dynamiclimits['maxVel_ft_s']))
        is_violate_DH = np.any(results_dh_ft_s > dynamiclimits['maxVertRate_ft_s'])
        
        #np.random.set_state(state)
        #seed=seed+1
        
        #Check if track is valid
        if not (is_violate_L or is_violate_V or is_violate_DH):
            valid_results.append(result)
            X_Initial_total.append(S)
            all_results_by_X.append(all_results)
            total_results += 1
            #print(f"Resultado válido #{total_results} guardado.")
        else:
            #print(f"Altitude={is_violate_L}, Speed={ is_violate_V}, VRate={is_violate_DH} ")
            invalid_results.append(result)
            inX_Initial_total.append(S)
            inall_results_by_X.append(all_results)
            wrong_tracks+=1

            if adaptive_speed_kt is not None:
                min_speed_kt = dynamiclimits['minVel_ft_s'] / 1.68780972222222
                max_speed_kt = dynamiclimits['maxVel_ft_s'] / 1.68780972222222
                speed_step_kt = max(1.0, 0.05 * max(1.0, adaptive_speed_kt))

                speed_ftps = np.asarray(result['speed_ftps'])
                mean_speed_kt = float(np.mean(speed_ftps)) / 1.68780972222222

                if is_violate_V:
                    has_low_speed_violation = np.any(speed_ftps < dynamiclimits['minVel_ft_s'])
                    has_high_speed_violation = np.any(speed_ftps > dynamiclimits['maxVel_ft_s'])

                    if has_low_speed_violation and not has_high_speed_violation:
                        adaptive_speed_kt = max(adaptive_speed_kt + speed_step_kt, min_speed_kt)
                    elif has_high_speed_violation and not has_low_speed_violation:
                        adaptive_speed_kt = min(adaptive_speed_kt - speed_step_kt, max_speed_kt)
                    else:
                        adaptive_speed_kt = np.clip(adaptive_speed_kt, min_speed_kt, max_speed_kt)

                elif is_violate_DH:
                    adaptive_speed_kt = max(min_speed_kt, adaptive_speed_kt - speed_step_kt)

                elif is_violate_L:
                    too_low = np.any(result['up_ft'] < min_alt_ft)
                    too_high = np.any(result['up_ft'] > max_alt_ft + 500)
                    if too_low and not too_high:
                        if mean_speed_kt < min_speed_kt:
                            adaptive_speed_kt = min(adaptive_speed_kt + speed_step_kt, max_speed_kt)
                        else:
                            adaptive_speed_kt = max(adaptive_speed_kt - speed_step_kt, min_speed_kt)
                    elif too_high and not too_low:
                        adaptive_speed_kt = max(adaptive_speed_kt - speed_step_kt, min_speed_kt)
                    else:
                        adaptive_speed_kt = np.clip(adaptive_speed_kt, min_speed_kt, max_speed_kt)

                adaptive_speed_kt = float(np.clip(adaptive_speed_kt, speed_edges[0], speed_edges[-1]))
                
    #print({f"Wrong tracks={wrong_tracks}"})
    #Convert output to dataframe
    X_Initial_total = pd.DataFrame(X_Initial_total, columns=Labels)
    inX_Initial_total = pd.DataFrame(inX_Initial_total, columns=Labels)

    #return valid_results, X_Initial_total, all_results_by_X, invalid_results, inX_Initial_total, inall_results_by_X
    #return valid_results
    return valid_results, X_Initial_total, all_results_by_X


def gen_track(vehicle_filename, duration, number_of_tracks,seed=False, desired_speed_kt=None, straight_flight=False, trajectory_csv_filename=None):
    global global_model_name
    start_time = time.time()
    try:

        if trajectory_csv_filename is not None:
            if desired_speed_kt is None:
                raise ValueError("desired_speed_kt is required when trajectory_csv_filename is provided.")

            lla_points = _load_lla_points_from_csv(trajectory_csv_filename)
            # In CSV mode, straight_flight is ignored by design.
            Results, X, T = generate_valid_results(
                data_model=None,
                number_of_tracks=number_of_tracks,
                duration=duration,
                seed=seed,
                desired_speed_kt=desired_speed_kt,
                straight_flight=False,
                lla_points=lla_points,
            )
            return Results

        if not os.path.isfile(vehicle_filename): 
            package_mat_dir = files(__name__).joinpath('data') 
            full_filename = os.path.join(package_mat_dir, vehicle_filename) 
            if not os.path.isfile(full_filename): 
                print(f"The file {vehicle_filename} was not found in the current directory or in the package.") 
                return None
            else: vehicle_filename = full_filename 
        
        global_model_name = os.path.splitext(os.path.basename(vehicle_filename))[0]
        #Load matlab data
        data_model = scipy.io.loadmat(vehicle_filename, mat_dtype=True)
        Results, X, T=generate_valid_results(data_model, number_of_tracks, duration, seed, desired_speed_kt=desired_speed_kt, straight_flight=straight_flight)
        #Results, X, T, IRES, Xi, iT=generate_valid_results(data_model,number_of_tracks, sample_time)
        end_time = time.time()  # End time
        total_time = end_time - start_time
        #print(f"Total time taken: {total_time} seconds")
        #return Results, X, T
        return Results
    except FileNotFoundError:
        print(f"The file {vehicle_filename} was not found.")
        return None
    except Exception as e:
        print(f"An error occurred while loading the file: {e}")
        return None


def get_unique_filename(base_name, extension):
    i = 0
    new_name = f"{base_name}{extension}"
    while os.path.exists(new_name):
        i += 1
        new_name = f"{base_name}_{i}{extension}"
    return new_name


def generate_plot(RESULTS, title=None, show_legend=True, equal_aspect=True, colors=None):
    global global_model_name
    if title is None:
        title = global_model_name.replace('_', ' ') if global_model_name else "Track Generation Tool"
    
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')

    for i in range(len(RESULTS)):
        north_ft = RESULTS[i]['north_ft']
        east_ft = RESULTS[i]['east_ft']
        up_ft = RESULTS[i]['up_ft']
        if colors is None:
            ax.plot3D(north_ft, east_ft, up_ft, label=f'Track {i+1}')
        else:
            ax.plot3D(north_ft, east_ft, up_ft, label=f'Track {i+1}', color=colors[i % len(colors)])
        ax.plot3D(north_ft[0], east_ft[0], up_ft[0], marker='o', markersize=5, color='green')  # Mark initial point

    ax.set_xlabel('North (ft)')
    ax.set_ylabel('East (ft)')
    ax.set_zlabel('Up (ft)')

    ax.set_title(title)
    if equal_aspect:
        ax.set_aspect('equal')
    if show_legend:
        ax.legend()

    plt.show()

    
def save_as_Matlab(RESULTS, name=None):
    global global_model_name
    if name is None:
        name = global_model_name if global_model_name else "result_model"
    filename = get_unique_filename(f"{name}_Result", '.mat')
    scipy.io.savemat(filename, {'Tracks': RESULTS})
    print(f"Saved MATLAB file: {filename}")


def get_mat_files():
    mat_dir = files(__name__).joinpath('data')
    return [f for f in os.listdir(mat_dir) if f.endswith('.mat')]


def save_to_csv(results, filename_base=None):
    global global_model_name
    if not results:
        print("The results list is empty. No file will be saved.")
        return
    
    if filename_base is None:
        filename_base = global_model_name if global_model_name else "result_model"
    
    # Define max number of rows per file
    MAX_ROWS = 1000000

    # Extract field names
    fieldnames = ['Aircraft_ID'] + list(results[0].keys())

    row_count = 0
    
    filename = get_unique_filename(f"{filename_base}_Result", '.csv')
    file = open(filename, mode='w', newline='')
    writer = csv.writer(file)
    
    # Write header
    writer.writerow(fieldnames)
    print(f"Writing to {filename}...")

    for aircraft_id, result in enumerate(results, start=1):
        num_rows = len(result['time'])

        if row_count + num_rows > MAX_ROWS:
            if file:
                file.close()  
            
            filename = get_unique_filename(f"{filename_base}_Result", '.csv')
            file = open(filename, mode='w', newline='')
            writer = csv.writer(file)

            # Write header
            writer.writerow(fieldnames)

            print(f"Writing to {filename}...")
            row_count = 0  # Reset row count for the new file

    
        for i in range(num_rows):
            row = [aircraft_id]  
            row_values = []
            for key in result.keys():
                value = result[key]
                if np.isscalar(value):
                    row_values.append(value)
                else:
                    row_values.append(value[i])
            row.extend(row_values)
            writer.writerow(row)
        
        row_count += num_rows 

    if file:
        file.close()

    print("Data successfully saved to " + filename)

